import React, { useState } from 'react';
import Header from './components/Layout/Header';
import Navigation from './components/Layout/Navigation';
import Dashboard from './components/Dashboard/Dashboard';
import FlightNetwork from './components/FlightNetwork/FlightNetwork';
import WhatIfSimulator from './components/WhatIfSimulator/WhatIfSimulator';
import NLPInsights from './components/NLPInsights/NLPInsights';
import Analytics from './components/Analytics/Analytics';

function App() {
  const [activeSection, setActiveSection] = useState('dashboard');

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'network':
        return <FlightNetwork />;
      case 'simulator':
        return <WhatIfSimulator />;
      case 'insights':
        return <NLPInsights />;
      case 'analytics':
        return <Analytics />;
      case 'settings':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <p className="text-gray-600">Settings panel coming soon...</p>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Navigation activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 p-6">
          {renderActiveSection()}
        </main>
      </div>
    </div>
  );
}

export default App;