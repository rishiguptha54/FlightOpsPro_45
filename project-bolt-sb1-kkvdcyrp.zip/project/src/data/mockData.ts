import { Flight, DelayData, AirlineStats, WeatherData, FlightDependency } from '../types';

export const mockFlights: Flight[] = [
  {
    id: '1',
    callsign: 'AI-601',
    airline: 'Air India',
    origin: 'BOM',
    destination: 'DEL',
    scheduledDeparture: '2025-01-15T08:30:00Z',
    actualDeparture: '2025-01-15T09:15:00Z',
    scheduledArrival: '2025-01-15T11:00:00Z',
    actualArrival: '2025-01-15T11:45:00Z',
    delay: 45,
    status: 'delayed',
    aircraftType: 'A320',
    gate: 'A12',
    runway: '09/27'
  },
  {
    id: '2',
    callsign: '6E-203',
    airline: 'IndiGo',
    origin: 'DEL',
    destination: 'BOM',
    scheduledDeparture: '2025-01-15T10:15:00Z',
    actualDeparture: '2025-01-15T10:10:00Z',
    scheduledArrival: '2025-01-15T12:45:00Z',
    delay: -5,
    status: 'on-time',
    aircraftType: 'A321',
    gate: 'B7',
    runway: '05/23'
  },
  {
    id: '3',
    callsign: 'SG-142',
    airline: 'SpiceJet',
    origin: 'BOM',
    destination: 'DEL',
    scheduledDeparture: '2025-01-15T14:20:00Z',
    actualDeparture: '2025-01-15T15:35:00Z',
    scheduledArrival: '2025-01-15T16:50:00Z',
    actualArrival: '2025-01-15T18:05:00Z',
    delay: 75,
    status: 'delayed',
    aircraftType: 'B737',
    gate: 'C3',
    runway: '09/27'
  },
  {
    id: '4',
    callsign: 'UK-953',
    airline: 'Vistara',
    origin: 'DEL',
    destination: 'BOM',
    scheduledDeparture: '2025-01-15T16:45:00Z',
    actualDeparture: '2025-01-15T16:40:00Z',
    scheduledArrival: '2025-01-15T19:15:00Z',
    delay: -5,
    status: 'on-time',
    aircraftType: 'A320neo',
    gate: 'D15',
    runway: '11/29'
  },
  {
    id: '5',
    callsign: 'AI-131',
    airline: 'Air India',
    origin: 'BOM',
    destination: 'DEL',
    scheduledDeparture: '2025-01-15T18:30:00Z',
    actualDeparture: '2025-01-15T19:45:00Z',
    scheduledArrival: '2025-01-15T21:00:00Z',
    actualArrival: '2025-01-15T22:15:00Z',
    delay: 75,
    status: 'delayed',
    aircraftType: 'B787',
    gate: 'A8',
    runway: '09/27'
  }
];

export const mockDelayData: DelayData[] = [
  { timeSlot: '06:00', avgDelay: 5, flightCount: 12, date: '2025-01-15' },
  { timeSlot: '07:00', avgDelay: 8, flightCount: 18, date: '2025-01-15' },
  { timeSlot: '08:00', avgDelay: 15, flightCount: 25, date: '2025-01-15' },
  { timeSlot: '09:00', avgDelay: 22, flightCount: 32, date: '2025-01-15' },
  { timeSlot: '10:00', avgDelay: 18, flightCount: 28, date: '2025-01-15' },
  { timeSlot: '11:00', avgDelay: 12, flightCount: 22, date: '2025-01-15' },
  { timeSlot: '12:00', avgDelay: 25, flightCount: 30, date: '2025-01-15' },
  { timeSlot: '13:00', avgDelay: 35, flightCount: 35, date: '2025-01-15' },
  { timeSlot: '14:00', avgDelay: 42, flightCount: 40, date: '2025-01-15' },
  { timeSlot: '15:00', avgDelay: 38, flightCount: 38, date: '2025-01-15' },
  { timeSlot: '16:00', avgDelay: 45, flightCount: 42, date: '2025-01-15' },
  { timeSlot: '17:00', avgDelay: 52, flightCount: 45, date: '2025-01-15' },
  { timeSlot: '18:00', avgDelay: 58, flightCount: 48, date: '2025-01-15' },
  { timeSlot: '19:00', avgDelay: 48, flightCount: 40, date: '2025-01-15' },
  { timeSlot: '20:00', avgDelay: 32, flightCount: 35, date: '2025-01-15' },
  { timeSlot: '21:00', avgDelay: 28, flightCount: 25, date: '2025-01-15' },
  { timeSlot: '22:00', avgDelay: 18, flightCount: 20, date: '2025-01-15' },
  { timeSlot: '23:00', avgDelay: 12, flightCount: 15, date: '2025-01-15' }
];

export const mockAirlineStats: AirlineStats[] = [
  { airline: 'IndiGo', avgDelay: 12.5, totalFlights: 156, onTimePercentage: 82.1, rank: 1 },
  { airline: 'Vistara', avgDelay: 15.8, totalFlights: 89, onTimePercentage: 78.3, rank: 2 },
  { airline: 'Air India', avgDelay: 28.4, totalFlights: 124, onTimePercentage: 65.2, rank: 3 },
  { airline: 'SpiceJet', avgDelay: 32.7, totalFlights: 98, onTimePercentage: 61.8, rank: 4 },
  { airline: 'GoAir', avgDelay: 35.2, totalFlights: 76, onTimePercentage: 58.9, rank: 5 }
];

export const mockWeatherData: WeatherData[] = [
  { timestamp: '06:00', visibility: 8.5, windSpeed: 12, precipitation: 0, temperature: 24, conditions: 'Clear' },
  { timestamp: '07:00', visibility: 7.2, windSpeed: 15, precipitation: 0, temperature: 26, conditions: 'Partly Cloudy' },
  { timestamp: '08:00', visibility: 6.8, windSpeed: 18, precipitation: 0, temperature: 28, conditions: 'Partly Cloudy' },
  { timestamp: '09:00', visibility: 5.5, windSpeed: 22, precipitation: 2, temperature: 30, conditions: 'Light Rain' },
  { timestamp: '10:00', visibility: 4.2, windSpeed: 25, precipitation: 5, temperature: 29, conditions: 'Rain' },
  { timestamp: '11:00', visibility: 3.8, windSpeed: 28, precipitation: 8, temperature: 28, conditions: 'Heavy Rain' },
  { timestamp: '12:00', visibility: 6.5, windSpeed: 20, precipitation: 3, temperature: 31, conditions: 'Light Rain' },
  { timestamp: '13:00', visibility: 8.0, windSpeed: 16, precipitation: 0, temperature: 33, conditions: 'Cloudy' },
  { timestamp: '14:00', visibility: 9.2, windSpeed: 14, precipitation: 0, temperature: 35, conditions: 'Clear' }
];

export const mockFlightDependencies: FlightDependency[] = [
  { source: 'AI-601', target: '6E-203', influence: 0.85, delay: 20 },
  { source: '6E-203', target: 'SG-142', influence: 0.62, delay: 15 },
  { source: 'SG-142', target: 'UK-953', influence: 0.45, delay: 10 },
  { source: 'UK-953', target: 'AI-131', influence: 0.72, delay: 25 },
  { source: 'AI-601', target: 'SG-142', influence: 0.38, delay: 8 },
  { source: '6E-203', target: 'AI-131', influence: 0.55, delay: 12 }
];