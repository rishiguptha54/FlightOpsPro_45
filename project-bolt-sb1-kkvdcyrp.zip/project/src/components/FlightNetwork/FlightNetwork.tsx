import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { mockFlightDependencies, mockFlights } from '../../data/mockData';

const FlightNetwork: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); // Clear previous render

    const width = 800;
    const height = 600;
    const margin = 40;

    svg.attr("width", width).attr("height", height);

    // Create nodes from flights
    const nodes = mockFlights.map(flight => ({
      id: flight.callsign,
      flight: flight,
      delay: flight.delay,
      x: Math.random() * (width - 2 * margin) + margin,
      y: Math.random() * (height - 2 * margin) + margin,
    }));

    // Create links from dependencies
    const links = mockFlightDependencies.map(dep => ({
      source: dep.source,
      target: dep.target,
      influence: dep.influence,
      delay: dep.delay,
    }));

    // Create force simulation
    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(150))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(25));

    // Create links
    const link = svg.append("g")
      .selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke", "#9CA3AF")
      .attr("stroke-width", (d: any) => Math.sqrt(d.influence) * 3)
      .attr("stroke-opacity", 0.6);

    // Create nodes
    const node = svg.append("g")
      .selectAll("circle")
      .data(nodes)
      .enter().append("circle")
      .attr("r", 20)
      .attr("fill", (d: any) => {
        if (d.delay > 30) return "#EF4444"; // Red for high delays
        if (d.delay > 0) return "#F97316"; // Orange for delays
        return "#10B981"; // Green for on-time
      })
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .style("cursor", "pointer");

    // Add labels
    const labels = svg.append("g")
      .selectAll("text")
      .data(nodes)
      .enter().append("text")
      .text((d: any) => d.id)
      .attr("font-size", "10px")
      .attr("text-anchor", "middle")
      .attr("dy", 4)
      .attr("fill", "#fff")
      .attr("font-weight", "bold")
      .style("pointer-events", "none");

    // Add tooltips
    const tooltip = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("opacity", 0)
      .style("position", "absolute")
      .style("background", "rgba(0, 0, 0, 0.8)")
      .style("color", "white")
      .style("padding", "8px")
      .style("border-radius", "4px")
      .style("font-size", "12px")
      .style("pointer-events", "none");

    node
      .on("mouseover", function(event, d: any) {
        tooltip.transition().duration(200).style("opacity", .9);
        tooltip.html(`
          <strong>${d.flight.callsign}</strong><br/>
          ${d.flight.origin} → ${d.flight.destination}<br/>
          Delay: ${d.delay > 0 ? '+' + d.delay : d.delay} min<br/>
          Airline: ${d.flight.airline}
        `)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", function() {
        tooltip.transition().duration(500).style("opacity", 0);
      });

    // Update positions on simulation tick
    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("cx", (d: any) => Math.max(20, Math.min(width - 20, d.x)))
        .attr("cy", (d: any) => Math.max(20, Math.min(height - 20, d.y)));

      labels
        .attr("x", (d: any) => Math.max(20, Math.min(width - 20, d.x)))
        .attr("y", (d: any) => Math.max(20, Math.min(height - 20, d.y)));
    });

    // Cleanup function
    return () => {
      tooltip.remove();
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Flight Dependency Network</h2>
        <p className="text-gray-600">Visualize flight connections and delay propagation patterns</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Network Visualization */}
        <div className="xl:col-span-3 bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Network Graph</h3>
            <div className="flex items-center space-x-4 text-xs">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span>On-time</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                <span>Delayed</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span>High Delay</span>
              </div>
            </div>
          </div>
          
          <div className="border border-gray-200 rounded-lg overflow-hidden">
            <svg ref={svgRef} className="w-full"></svg>
          </div>
          
          <p className="text-sm text-gray-500 mt-2">
            Hover over nodes for flight details. Line thickness represents influence strength.
          </p>
        </div>

        {/* Network Stats */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Network Statistics</h3>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Nodes</span>
                <span className="font-semibold">{mockFlights.length}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Dependencies</span>
                <span className="font-semibold">{mockFlightDependencies.length}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Avg Influence</span>
                <span className="font-semibold">
                  {(mockFlightDependencies.reduce((sum, dep) => sum + dep.influence, 0) / mockFlightDependencies.length).toFixed(2)}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Critical Paths</span>
                <span className="font-semibold">3</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">High Influence Flights</h3>
            
            <div className="space-y-2">
              {mockFlightDependencies
                .sort((a, b) => b.influence - a.influence)
                .slice(0, 4)
                .map((dep, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">{dep.source}</span>
                    <span className="text-xs text-gray-600">{(dep.influence * 100).toFixed(0)}%</span>
                  </div>
                ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h3>
            
            <div className="space-y-2 text-sm">
              <div className="p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-yellow-800">
                  <strong>Priority:</strong> Monitor AI-601 - highest influence on network delays
                </p>
              </div>
              
              <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-blue-800">
                  <strong>Optimize:</strong> Consider rescheduling SG-142 to reduce cascading effects
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightNetwork;