import React from 'react';
import { DelayData } from '../../types';

interface DelayHeatmapProps {
  data: DelayData[];
}

const DelayHeatmap: React.FC<DelayHeatmapProps> = ({ data }) => {
  const getHeatmapColor = (delay: number) => {
    if (delay < 10) return 'bg-green-100 text-green-800';
    if (delay < 20) return 'bg-yellow-100 text-yellow-800';
    if (delay < 35) return 'bg-orange-100 text-orange-800';
    if (delay < 50) return 'bg-red-100 text-red-800';
    return 'bg-red-200 text-red-900';
  };

  const formatTime = (time: string) => {
    return time.replace(':00', '');
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Delay Heatmap by Time Slot</h3>
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-green-100"></div>
            <span>&lt;10min</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-yellow-100"></div>
            <span>10-20min</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-orange-100"></div>
            <span>20-35min</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-red-100"></div>
            <span>35-50min</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded bg-red-200"></div>
            <span>&gt;50min</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-6 sm:grid-cols-9 lg:grid-cols-12 gap-2">
        {data.map((slot) => (
          <div
            key={slot.timeSlot}
            className={`relative p-3 rounded-lg text-center cursor-pointer transition-all hover:scale-105 ${getHeatmapColor(slot.avgDelay)}`}
            title={`${slot.timeSlot}: ${slot.avgDelay}min avg delay, ${slot.flightCount} flights`}
          >
            <div className="text-xs font-semibold mb-1">{formatTime(slot.timeSlot)}</div>
            <div className="text-sm font-bold">{Math.round(slot.avgDelay)}m</div>
            <div className="text-xs opacity-75">{slot.flightCount}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-xs text-gray-500">
        Hover over cells for detailed information. Numbers show average delay (minutes) and flight count.
      </div>
    </div>
  );
};

export default DelayHeatmap;