import React from 'react';
import { Clock, Plane, AlertTriangle, TrendingUp, Users } from 'lucide-react';
import MetricCard from './MetricCard';
import DelayHeatmap from './DelayHeatmap';
import AirlineRanking from './AirlineRanking';
import { mockDelayData, mockAirlineStats, mockFlights } from '../../data/mockData';

const Dashboard: React.FC = () => {
  // Calculate metrics from mock data
  const totalFlights = mockFlights.length;
  const delayedFlights = mockFlights.filter(f => f.delay > 0).length;
  const avgDelay = mockFlights.reduce((acc, f) => acc + f.delay, 0) / mockFlights.length;
  const mostDelayedAirline = mockAirlineStats.reduce((prev, curr) => 
    prev.avgDelay > curr.avgDelay ? prev : curr
  );
  const peakCongestionSlot = mockDelayData.reduce((prev, curr) => 
    prev.avgDelay > curr.avgDelay ? prev : curr
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Flight Operations Dashboard</h2>
        <p className="text-gray-600">Real-time delay prediction and optimization insights</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <MetricCard
          title="Average Delay Today"
          value={`${Math.round(avgDelay)}min`}
          subtitle={`${delayedFlights}/${totalFlights} flights delayed`}
          icon={Clock}
          color="red"
          trend={{ value: -12.5, isPositive: true }}
        />
        
        <MetricCard
          title="Most Delayed Airline"
          value={mostDelayedAirline.airline}
          subtitle={`${Math.round(mostDelayedAirline.avgDelay)}min avg delay`}
          icon={Plane}
          color="orange"
        />
        
        <MetricCard
          title="Peak Congestion Slot"
          value={peakCongestionSlot.timeSlot}
          subtitle={`${Math.round(peakCongestionSlot.avgDelay)}min avg delay`}
          icon={AlertTriangle}
          color="red"
        />
        
        <MetricCard
          title="Flight Volume"
          value={totalFlights}
          subtitle="Flights tracked today"
          icon={Users}
          color="blue"
          trend={{ value: 8.3, isPositive: true }}
        />
        
        <MetricCard
          title="System Efficiency"
          value="72.4%"
          subtitle="On-time performance"
          icon={TrendingUp}
          color="green"
          trend={{ value: 5.2, isPositive: true }}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <DelayHeatmap data={mockDelayData} />
        </div>
        
        <div>
          <AirlineRanking data={mockAirlineStats} />
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Flight Updates</h3>
        <div className="space-y-3">
          {mockFlights.slice(0, 5).map((flight) => (
            <div key={flight.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
              <div className="flex items-center space-x-3">
                <div className={`w-2 h-2 rounded-full ${
                  flight.status === 'delayed' ? 'bg-red-500' : 
                  flight.status === 'on-time' ? 'bg-green-500' : 'bg-gray-400'
                }`}></div>
                <span className="font-medium text-gray-900">{flight.callsign}</span>
                <span className="text-gray-500">{flight.origin} → {flight.destination}</span>
              </div>
              <div className="text-right">
                <span className={`text-sm font-medium ${
                  flight.delay > 0 ? 'text-red-600' : 'text-green-600'
                }`}>
                  {flight.delay > 0 ? `+${flight.delay}min` : 'On-time'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;