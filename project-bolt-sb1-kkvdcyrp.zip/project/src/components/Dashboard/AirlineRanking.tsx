import React from 'react';
import { AirlineStats } from '../../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface AirlineRankingProps {
  data: AirlineStats[];
}

const AirlineRanking: React.FC<AirlineRankingProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Airline Performance Ranking</h3>
      
      <div className="space-y-4">
        {data.map((airline, index) => (
          <div
            key={airline.airline}
            className="flex items-center justify-between p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
          >
            <div className="flex items-center space-x-4">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
                index === 0 ? 'bg-yellow-100 text-yellow-800' :
                index === 1 ? 'bg-gray-100 text-gray-600' :
                index === 2 ? 'bg-orange-100 text-orange-700' :
                'bg-gray-50 text-gray-500'
              }`}>
                {airline.rank}
              </div>
              
              <div>
                <p className="font-semibold text-gray-900">{airline.airline}</p>
                <p className="text-sm text-gray-600">{airline.totalFlights} flights today</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">
                  {airline.onTimePercentage.toFixed(1)}% On-Time
                </p>
                <p className="text-xs text-gray-500">
                  {airline.avgDelay.toFixed(1)}min avg delay
                </p>
              </div>
              
              <div className="flex items-center">
                {airline.onTimePercentage >= 75 ? (
                  <TrendingUp className="w-5 h-5 text-green-500" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-500" />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 text-xs text-gray-500 border-t pt-4">
        Rankings based on on-time percentage and average delay minutes. Updated every 15 minutes.
      </div>
    </div>
  );
};

export default AirlineRanking;