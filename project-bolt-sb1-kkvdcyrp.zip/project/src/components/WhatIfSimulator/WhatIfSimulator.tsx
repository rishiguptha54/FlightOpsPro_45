import React, { useState } from 'react';
import { Play, RotateCcw, TrendingDown, TrendingUp } from 'lucide-react';
import { mockFlights } from '../../data/mockData';

const WhatIfSimulator: React.FC = () => {
  const [selectedFlight, setSelectedFlight] = useState(mockFlights[0]);
  const [scheduleAdjustment, setScheduleAdjustment] = useState(0);
  const [simulationResult, setSimulationResult] = useState<{
    systemDelayChange: number;
    affectedFlights: number;
    cascadingEffect: string;
  } | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const runSimulation = async () => {
    setIsSimulating(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock simulation results based on adjustment
    const delayChange = Math.round((scheduleAdjustment / 10) * -2.5 + Math.random() * 5 - 2.5);
    const affectedFlights = Math.max(1, Math.round(Math.abs(scheduleAdjustment) / 5) + Math.floor(Math.random() * 3));
    
    let cascadingEffect = 'Minimal';
    if (Math.abs(delayChange) > 15) cascadingEffect = 'High';
    else if (Math.abs(delayChange) > 8) cascadingEffect = 'Moderate';

    setSimulationResult({
      systemDelayChange: delayChange,
      affectedFlights,
      cascadingEffect
    });
    setIsSimulating(false);
  };

  const resetSimulation = () => {
    setSimulationResult(null);
    setScheduleAdjustment(0);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">What-If Scenario Simulator</h2>
        <p className="text-gray-600">Test schedule adjustments and analyze their impact on system-wide delays</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Simulation Controls */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Simulation Parameters</h3>
          
          <div className="space-y-6">
            {/* Flight Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Flight
              </label>
              <select
                value={selectedFlight.id}
                onChange={(e) => setSelectedFlight(mockFlights.find(f => f.id === e.target.value)!)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {mockFlights.map((flight) => (
                  <option key={flight.id} value={flight.id}>
                    {flight.callsign} - {flight.origin} → {flight.destination} 
                    ({flight.delay > 0 ? `+${flight.delay}min` : 'On-time'})
                  </option>
                ))}
              </select>
            </div>

            {/* Schedule Adjustment */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Schedule Adjustment: {scheduleAdjustment > 0 ? '+' : ''}{scheduleAdjustment} minutes
              </label>
              <input
                type="range"
                min={-30}
                max={30}
                step={5}
                value={scheduleAdjustment}
                onChange={(e) => setScheduleAdjustment(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>-30min</span>
                <span>0</span>
                <span>+30min</span>
              </div>
            </div>

            {/* Flight Details */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">Selected Flight Details</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-600">Callsign:</span>
                  <span className="ml-2 font-medium">{selectedFlight.callsign}</span>
                </div>
                <div>
                  <span className="text-gray-600">Airline:</span>
                  <span className="ml-2 font-medium">{selectedFlight.airline}</span>
                </div>
                <div>
                  <span className="text-gray-600">Route:</span>
                  <span className="ml-2 font-medium">{selectedFlight.origin} → {selectedFlight.destination}</span>
                </div>
                <div>
                  <span className="text-gray-600">Current Delay:</span>
                  <span className={`ml-2 font-medium ${
                    selectedFlight.delay > 0 ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {selectedFlight.delay > 0 ? `+${selectedFlight.delay}min` : 'On-time'}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <button
                onClick={runSimulation}
                disabled={isSimulating}
                className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Play className="w-4 h-4" />
                <span>{isSimulating ? 'Running...' : 'Run Simulation'}</span>
              </button>
              
              <button
                onClick={resetSimulation}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Simulation Results</h3>
          
          {!simulationResult && !isSimulating && (
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <Play className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p>Run a simulation to see the results</p>
              </div>
            </div>
          )}

          {isSimulating && (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-3"></div>
                <p className="text-gray-600">Running simulation...</p>
                <p className="text-sm text-gray-500 mt-1">Analyzing cascading effects</p>
              </div>
            </div>
          )}

          {simulationResult && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">System-wide Delay Change</span>
                    <div className="flex items-center space-x-2">
                      {simulationResult.systemDelayChange < 0 ? (
                        <TrendingDown className="w-4 h-4 text-green-500" />
                      ) : (
                        <TrendingUp className="w-4 h-4 text-red-500" />
                      )}
                      <span className={`font-bold ${
                        simulationResult.systemDelayChange < 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {simulationResult.systemDelayChange > 0 ? '+' : ''}
                        {simulationResult.systemDelayChange} minutes
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Affected Flights</span>
                    <span className="font-bold text-gray-900">{simulationResult.affectedFlights} flights</span>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Cascading Effect Level</span>
                    <span className={`font-bold px-2 py-1 rounded-md text-xs ${
                      simulationResult.cascadingEffect === 'Minimal' ? 'bg-green-100 text-green-800' :
                      simulationResult.cascadingEffect === 'Moderate' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {simulationResult.cascadingEffect}
                    </span>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-2">Impact Analysis</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  {simulationResult.systemDelayChange < 0 ? (
                    <p className="text-green-700">✓ This adjustment would improve overall system performance</p>
                  ) : (
                    <p className="text-red-700">⚠ This adjustment may worsen overall system performance</p>
                  )}
                  
                  <p>• Estimated processing time: ~2.3 seconds</p>
                  <p>• Confidence level: 87%</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Recommendations */}
      {simulationResult && (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Optimization Recommendations</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">Optimal Schedule Adjustment</h4>
              <p className="text-sm text-blue-700">Based on current conditions, consider a -10 minute adjustment for maximum system efficiency.</p>
            </div>
            
            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h4 className="font-medium text-green-900 mb-2">Alternative Routes</h4>
              <p className="text-sm text-green-700">Gate B12 and Runway 05/23 are currently less congested and may reduce taxi time.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WhatIfSimulator;