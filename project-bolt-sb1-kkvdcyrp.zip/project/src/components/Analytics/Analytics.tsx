import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { mockDelayData, mockAirlineStats, mockWeatherData } from '../../data/mockData';

const Analytics: React.FC = () => {
  // Process weather data for correlation analysis
  const weatherImpact = mockWeatherData.map((weather, index) => ({
    time: weather.timestamp,
    visibility: weather.visibility,
    delay: mockDelayData[index]?.avgDelay || 0,
    precipitation: weather.precipitation,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Advanced Analytics</h2>
        <p className="text-gray-600">Deep dive into delay patterns, correlations, and predictive insights</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Delay Trends */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Hourly Delay Trends</h3>
          
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={mockDelayData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="timeSlot" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => value.replace(':00', '')}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                formatter={(value) => [`${value} min`, 'Avg Delay']}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Line 
                type="monotone" 
                dataKey="avgDelay" 
                stroke="#3B82F6" 
                strokeWidth={3}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
          
          <p className="text-sm text-gray-500 mt-2">
            Peak delay hours are typically 17:00-19:00 with average delays exceeding 50 minutes.
          </p>
        </div>

        {/* Airline Performance */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Airline Performance Comparison</h3>
          
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockAirlineStats}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="airline" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                formatter={(value, name) => [
                  name === 'avgDelay' ? `${value} min` : `${value}%`,
                  name === 'avgDelay' ? 'Avg Delay' : 'On-Time %'
                ]}
              />
              <Bar dataKey="avgDelay" fill="#EF4444" name="avgDelay" />
              <Bar dataKey="onTimePercentage" fill="#10B981" name="onTimePercentage" />
            </BarChart>
          </ResponsiveContainer>
          
          <p className="text-sm text-gray-500 mt-2">
            IndiGo leads with 82.1% on-time performance, while SpiceJet shows room for improvement.
          </p>
        </div>

        {/* Weather Impact */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Weather Impact on Delays</h3>
          
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weatherImpact}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => value.replace(':00', '')}
              />
              <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="delay" 
                stroke="#EF4444" 
                strokeWidth={2}
                name="Delay (min)"
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="visibility" 
                stroke="#3B82F6" 
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Visibility (km)"
              />
            </LineChart>
          </ResponsiveContainer>
          
          <p className="text-sm text-gray-500 mt-2">
            Strong negative correlation between visibility and delays. Rain periods (09:00-12:00) show significant impact.
          </p>
        </div>

        {/* Predictive Insights */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Predictive Insights</h3>
          
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <h4 className="font-medium text-red-900 mb-2">🚨 High Risk Alert</h4>
              <p className="text-sm text-red-700">
                Weather forecast shows decreasing visibility from 15:00. Expect 15-20% increase in delays for evening flights.
              </p>
            </div>
            
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <h4 className="font-medium text-yellow-900 mb-2">⚠️ Capacity Warning</h4>
              <p className="text-sm text-yellow-700">
                Runway 09/27 approaching capacity limits. Consider redistributing traffic to alternate runways.
              </p>
            </div>
            
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">💡 Optimization Opportunity</h4>
              <p className="text-sm text-blue-700">
                Early morning slots (06:00-08:00) consistently underutilized. Potential for schedule optimization.
              </p>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Model Performance Metrics</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Accuracy:</span>
                  <span className="font-medium">87.3%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Precision:</span>
                  <span className="font-medium">84.1%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Recall:</span>
                  <span className="font-medium">91.2%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">F1-Score:</span>
                  <span className="font-medium">87.5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Machine Learning Insights */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Machine Learning Model Insights</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Feature Importance</h4>
            <div className="space-y-2 text-sm text-left">
              <div className="flex justify-between">
                <span>Time Slot</span>
                <span className="font-bold">32%</span>
              </div>
              <div className="flex justify-between">
                <span>Weather</span>
                <span className="font-bold">28%</span>
              </div>
              <div className="flex justify-between">
                <span>Airline</span>
                <span className="font-bold">24%</span>
              </div>
              <div className="flex justify-between">
                <span>Aircraft Type</span>
                <span className="font-bold">16%</span>
              </div>
            </div>
          </div>

          <div className="text-center p-4 bg-green-50 rounded-lg">
            <h4 className="font-medium text-green-900 mb-2">Prediction Horizon</h4>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-green-700">Next 1 hour:</span>
                <div className="font-bold text-2xl text-green-600">94%</div>
                <span className="text-xs text-green-600">accuracy</span>
              </div>
              <div>
                <span className="text-green-700">Next 6 hours:</span>
                <div className="font-bold text-lg text-green-600">87%</div>
                <span className="text-xs text-green-600">accuracy</span>
              </div>
            </div>
          </div>

          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <h4 className="font-medium text-purple-900 mb-2">Model Updates</h4>
            <div className="text-sm text-purple-700">
              <p>Last retrained:</p>
              <p className="font-bold">2 hours ago</p>
              <p className="mt-2">Training data:</p>
              <p className="font-bold">45,823 flights</p>
              <p className="mt-2">Next update:</p>
              <p className="font-bold">In 4 hours</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;