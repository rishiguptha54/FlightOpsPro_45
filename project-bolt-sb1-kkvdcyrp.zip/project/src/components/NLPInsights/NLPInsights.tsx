import React, { useState } from 'react';
import { Send, MessageSquare, BarChart3, Clock, Plane } from 'lucide-react';
import { mockAirlineStats, mockFlights, mockDelayData } from '../../data/mockData';

interface QueryResult {
  query: string;
  type: 'chart' | 'table' | 'metric';
  data: any;
  summary: string;
}

const NLPInsights: React.FC = () => {
  const [query, setQuery] = useState('');
  const [queryHistory, setQueryHistory] = useState<QueryResult[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const processNLPQuery = async (userQuery: string) => {
    setIsProcessing(true);
    
    // Simulate API processing time
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const lowercaseQuery = userQuery.toLowerCase();
    let result: QueryResult;

    if (lowercaseQuery.includes('airline') && (lowercaseQuery.includes('delay') || lowercaseQuery.includes('rank'))) {
      result = {
        query: userQuery,
        type: 'table',
        data: mockAirlineStats.slice(0, 5),
        summary: `Found ${mockAirlineStats.length} airlines with performance data. SpiceJet has the highest average delay at 32.7 minutes.`
      };
    } else if (lowercaseQuery.includes('time') && lowercaseQuery.includes('delay')) {
      const peakHour = mockDelayData.reduce((prev, curr) => prev.avgDelay > curr.avgDelay ? prev : curr);
      result = {
        query: userQuery,
        type: 'chart',
        data: mockDelayData.slice(12, 18), // Evening hours
        summary: `Peak delay time is ${peakHour.timeSlot} with ${peakHour.avgDelay} minutes average delay. Evening hours (17:00-19:00) show highest congestion.`
      };
    } else if (lowercaseQuery.includes('flight') && lowercaseQuery.includes('status')) {
      const delayedFlights = mockFlights.filter(f => f.delay > 0);
      result = {
        query: userQuery,
        type: 'table',
        data: delayedFlights,
        summary: `Currently tracking ${mockFlights.length} flights. ${delayedFlights.length} flights are delayed with an average delay of ${(delayedFlights.reduce((acc, f) => acc + f.delay, 0) / delayedFlights.length).toFixed(1)} minutes.`
      };
    } else {
      // Default response for unrecognized queries
      result = {
        query: userQuery,
        type: 'metric',
        data: {
          totalFlights: mockFlights.length,
          delayedFlights: mockFlights.filter(f => f.delay > 0).length,
          avgDelay: (mockFlights.reduce((acc, f) => acc + f.delay, 0) / mockFlights.length).toFixed(1)
        },
        summary: 'Here\'s a summary of current flight operations. For more specific insights, try asking about airline rankings, delay patterns by time, or flight status updates.'
      };
    }

    setQueryHistory(prev => [result, ...prev]);
    setIsProcessing(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      processNLPQuery(query.trim());
      setQuery('');
    }
  };

  const suggestedQueries = [
    "Show top 5 most delayed airlines this week",
    "What are the worst evening delays today?", 
    "Which flights are currently delayed?",
    "Show me delay patterns by hour"
  ];

  const renderQueryResult = (result: QueryResult) => {
    switch (result.type) {
      case 'table':
        if (Array.isArray(result.data) && result.data[0]?.airline) {
          // Airline data
          return (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-2">Rank</th>
                    <th className="text-left py-2">Airline</th>
                    <th className="text-left py-2">Avg Delay</th>
                    <th className="text-left py-2">On-Time %</th>
                    <th className="text-left py-2">Total Flights</th>
                  </tr>
                </thead>
                <tbody>
                  {result.data.map((airline: any, index: number) => (
                    <tr key={airline.airline} className="border-b border-gray-100">
                      <td className="py-2">{airline.rank}</td>
                      <td className="py-2 font-medium">{airline.airline}</td>
                      <td className="py-2">{airline.avgDelay.toFixed(1)}min</td>
                      <td className="py-2">{airline.onTimePercentage.toFixed(1)}%</td>
                      <td className="py-2">{airline.totalFlights}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        } else if (Array.isArray(result.data) && result.data[0]?.callsign) {
          // Flight data
          return (
            <div className="space-y-2">
              {result.data.map((flight: any) => (
                <div key={flight.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className="font-medium">{flight.callsign}</span>
                    <span className="text-gray-500 ml-2">{flight.origin} → {flight.destination}</span>
                  </div>
                  <span className="text-red-600 font-medium">+{flight.delay}min</span>
                </div>
              ))}
            </div>
          );
        }
        break;

      case 'chart':
        return (
          <div className="grid grid-cols-3 gap-2">
            {result.data.map((slot: any) => (
              <div key={slot.timeSlot} className="text-center p-3 bg-red-100 text-red-800 rounded-lg">
                <div className="font-bold">{slot.timeSlot}</div>
                <div className="text-sm">{Math.round(slot.avgDelay)}min</div>
              </div>
            ))}
          </div>
        );

      case 'metric':
        return (
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{result.data.totalFlights}</div>
              <div className="text-sm text-blue-600">Total Flights</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{result.data.delayedFlights}</div>
              <div className="text-sm text-red-600">Delayed</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{result.data.avgDelay}min</div>
              <div className="text-sm text-orange-600">Avg Delay</div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">NLP Insights Panel</h2>
        <p className="text-gray-600">Ask questions about flight operations in natural language</p>
      </div>

      {/* Query Input */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex space-x-3">
            <div className="flex-1 relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask me anything about flight delays, airlines, or operations..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
                disabled={isProcessing}
              />
              <MessageSquare className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            <button
              type="submit"
              disabled={isProcessing || !query.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>{isProcessing ? 'Processing...' : 'Ask'}</span>
            </button>
          </div>
        </form>

        {/* Suggested Queries */}
        <div className="mt-4">
          <p className="text-sm font-medium text-gray-700 mb-2">Try asking:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedQueries.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setQuery(suggestion)}
                className="text-xs px-3 py-1 bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Query Results */}
      <div className="space-y-4">
        {queryHistory.map((result, index) => (
          <div key={index} className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <MessageSquare className="w-4 h-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900 mb-1">"{result.query}"</p>
                <p className="text-sm text-gray-600">{result.summary}</p>
              </div>
            </div>
            
            <div className="pl-9">
              {renderQueryResult(result)}
            </div>
          </div>
        ))}

        {queryHistory.length === 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No queries yet</h3>
            <p className="text-gray-600 mb-4">Start by asking a question about flight operations, delays, or airline performance.</p>
            <button
              onClick={() => setQuery(suggestedQueries[0])}
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              Try a sample query →
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default NLPInsights;