export interface Flight {
  id: string;
  callsign: string;
  airline: string;
  origin: string;
  destination: string;
  scheduledDeparture: string;
  actualDeparture?: string;
  scheduledArrival: string;
  actualArrival?: string;
  delay: number;
  status: 'on-time' | 'delayed' | 'cancelled';
  aircraftType: string;
  gate?: string;
  runway?: string;
}

export interface DelayData {
  timeSlot: string;
  avgDelay: number;
  flightCount: number;
  date: string;
}

export interface AirlineStats {
  airline: string;
  avgDelay: number;
  totalFlights: number;
  onTimePercentage: number;
  rank: number;
}

export interface WeatherData {
  timestamp: string;
  visibility: number;
  windSpeed: number;
  precipitation: number;
  temperature: number;
  conditions: string;
}

export interface FlightDependency {
  source: string;
  target: string;
  influence: number;
  delay: number;
}